(* task1 : ('a -> 'b) -> 'a -> 'b *)
fun task1 _ = raise Fail "Unimplemented"

(* task2 : ('a -> bool) -> 'a -> ('a -> 'b) -> (unit -> 'b) -> 'b *)
fun task2 _ = raise Fail "Unimplemented"

(* task3 : ('a -> 'b) -> 'a list -> ('b list -> 'c) -> 'c *)
fun task3 _ = raise Fail "Unimplemented"
