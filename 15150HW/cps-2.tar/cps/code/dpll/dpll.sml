
(* dpll : formula -> (assignment -> 'a) -> (unit -> 'a) -> 'a
 * REQUIRES: true
 * ENSURES : dpll formula sat unsat ==>
 *    - unsat ()     if there is no satisfying assignment to formula
 *    - sat asgn     if there is a satisfying assignment to formula, asgn
 *)
fun dpll
  (cnf : formula)
  (sat : assignment -> 'a)
  (unsat : unit -> 'a)
  : 'a =
    raise Fail "Unimplemented"
