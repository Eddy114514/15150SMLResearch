type vault = exn list


(* get      : 'a key -> vault -> 'a option
 * REQUIRES : M was produced from a valid sequence of operations for a vault
 * ENSURES  : get k M ==> SOME y   if there exists x in M such that
 *                                    decrypt k x ==> SOME y
 *                        NONE     otherwise
 *)
fun get (k : 'a key) (M : vault) : 'a option = raise Fail "Unimplemented"

(* replace  : 'a key -> 'a -> vault -> 'a option * vault
 * REQUIRES : M was produced from a valid sequence of operations for a vault
 * ENSURES  : replace k v M ==> (SOME y, M')   if there exists x in M such that
 *                                                decrypt k x = SOME y and M'
 *                                                contains x' = encrypt k v
 *                                                instead of x
 *                              (NONE, M)      otherwise
 *)
fun replace (k : 'a key) (v : 'a) (M : vault) : 'a option * vault =
  raise Fail "Unimplemented"

(* deposit  : 'a key -> 'a -> vault -> vault
 * REQUIRES : M was produced from a valid sequence of operations for a vault
 * ENSURES  : deposit k v M ==> M' such that M' contains x = encrypt k v,
 *            no other values x' = encrypt k v' (for any value v'),
 *            and all values y in M such that decrypt k y = NONE
 *)
fun deposit (k : 'a key) (v : 'a) (M : vault) : vault = raise Fail "Unimplemented"

(* withdraw : 'a key -> vault -> vault
 * REQUIRES : M was produced from a valid sequence of operations for a vault
 * ENSURES  : withdraw k M ==> M' where M' contains all elements x of M
 *              such that decrypt k x ==> NONE (and no others)
 *)
fun withdraw (k : 'a key) (M : vault) : vault = raise Fail "Unimplemented"

