structure RefRand : REFRAND =
struct
  (* Change me! *)
  type randstate = unit

  fun init _ = raise Fail "Unimplemented"

  fun next _ = raise Fail "Unimplemented"
end

val r1 = RefRand.init 15 2
val () = Test.int ("test 1", 4, RefRand.next r1)
val r2 = RefRand.init 15 3
val () = Test.int ("test 2", 1, RefRand.next r1)
val () = Test.int ("test 3", 9, RefRand.next r2)
