(* ArrayFn tests *)

val (l, f) = ArrayFn.new 1 3
val () = Test.int("test length", 3, l)
val () = f 1 := 5
val () = f 2 := 0
val () = Test.int("test 1", 1, ! (f 0))
val () = Test.int("test 2", 5, ! (f 1))
val () = Test.int("test 3", 0, ! (f 2))
val t1 = ! (f 3) handle Subscript => ~1
val () = Test.int("test 4", ~1, t1)
val t2 = ! (f ~1) handle Subscript => ~1
val () = Test.int("test 5", ~1, t2)

(* Memo tests *)

structure Fibonacci : RECURRENCE =
struct
  type t = int
  val a0 = 0
  val a1 = 1
  val comb = op+
end

structure Fib = Memo (
  structure ArrayFn = ArrayFn
  structure Recurrence = Fibonacci
)

(* create a new lookup table that only f may access *)
val f = Fib.memo ()
(* compute and store the 0th through 20th fibonacci numbers *)
val () = Test.int("get 20th", 6765, f 20)
(* requires no computation, just a lookup *)
val _ = f 20
(* requires no computation, just a lookup *)
val _ = f 10
(* compute and store the 21st through 30th fibonacci numbers *)
val _ = f 30
(* create a new lookup table that only g may access *)
val g = Fib.memo ()
(* compute and store the 0th through 30th fibonacci numbers *)
val _ = g 30
