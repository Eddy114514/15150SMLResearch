signature RECURRENCE = 
sig
  type t
  val a0 : t
  val a1 : t
  val comb : t * t -> t
end