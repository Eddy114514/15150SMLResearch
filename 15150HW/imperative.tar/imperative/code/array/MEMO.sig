signature MEMO =
sig
  type t
  val memo : unit -> int -> t
end
