functor Memo (
  structure ArrayFn : ARRAYFN
  structure Recurrence : RECURRENCE
) :> MEMO where type t = Recurrence.t =
struct
  (* Don't change this! *)
  type t = Recurrence.t
  (* memo : unit -> int -> t
   * REQUIRES: i >= 0
   * ENSURES: see spec in PDF
   *)
  fun memo _ = raise Fail "Unimplemented"
end
