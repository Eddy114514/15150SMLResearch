structure StreamFns :> STREAMFNS =
struct
  structure S = Stream

  (* concat: 'a Stream.t Stream.t -> 'a Stream.t
   * REQUIRES: s is productive
   * ENSURES:
   *     - concat s = s', a stream containing the elements of s concatenated
   *       together.
   *     - concat s is maximally lazy (evaluating concat s never exposes any
   *       elements of s).
   *)
  fun concat _ = raise Fail "Unimplemented"

  (* cycle: 'a Stream.t -> 'a Stream.t
   * REQUIRES: s is productive
   * ENSURES:
   *     - cycle s is productive
   *     - cycle s = s', a stream formed by infinitely repeating the elements of s
   *     - if s = Stream.empty, then cycle s = Stream.empty
   *     - cycle s is maximally lazy (evaluating cycle s never exposes any
   *       elements of s).
   *)
  fun cycle _ = raise Fail "Unimplemented"

  (* interleave: 'a Stream.t -> 'a Stream.t -> 'a Stream.t
   * REQUIRES: s1 and s2 are productive
   * ENSURES:
   *     - interleave s1 s2 is productive
   *     - interleave s1 s2 = s, where s contains alternating elements from s1
   *       and s2, starting with the first element of s1
   *     - If one stream ends early, the rest of the other stream is appended in its entirety
   *     - interleave s1 s2 is maximally lazy (evaluating interleave s1 s2
   *       never exposes any elements of s1 or s2).
   *)
  fun interleave _ = raise Fail "Unimplemented"

  (* double: 'a Stream.t -> 'a Stream.t
   * REQUIRES: s is productive
   * ENSURES:
   *     - double s is productive
   *     - double s = s', a stream containing the same elements as s, but with each
   *       element appearing twice in a row
   *     - double s is maximally lazy (evaluating double s never exposes any
   *       elements of s).
   *)
  fun double _ = raise Fail "Unimplemented"
end
