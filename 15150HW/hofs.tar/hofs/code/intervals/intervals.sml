type interval = int * int

(* all_available : interval list list -> interval list
 * REQUIRES:
 *   - Each person's obligations are disjoint
 *   - All schedules are well-formatted
 *   - Assume time starts at 0 and ends at the largest number given in the input
 *   - Assume that people can instantly transport themselves to and from commitments
 * ENSURES:
 *   all_available LL = L where L is a single list of all non-degenerate intervals
 *   in any order for which everyone is available.
 *)
fun all_available (_ : interval list list) : interval list =
  raise Fail "Unimplemented"
