datatype 'a tree = Empty | Node of 'a tree * 'a * 'a tree

structure TreeArray :> ARRAY =
  struct
    type 'a t = (int * 'a) tree

    exception Subscript

    val new_array = Empty

    fun nth Empty _ = raise Subscript
      | nth (Node (L, (n, x), R)) i =
          (case Int.compare (i, n) of
              LESS => nth L i
            | EQUAL => x
            | GREATER => nth R (i - n - 1)
          )

    fun insert Empty 0 x = Node (Empty, (0, x), Empty)
      | insert Empty _ _ = raise Subscript
      | insert (Node (L, (n, y), R)) i x = 
          if i <= n then Node (insert L i x, (n + 1, y), R)
          else Node (L, (n, y), insert R (i - n - 1) x)
    
    fun set Empty _ _ = raise Subscript
      | set (Node (L, (n, y), R)) i x =
          (case Int.compare (i, n) of
              LESS => Node (set L i x, (n, y), R)
            | EQUAL => Node (L, (n, x), R)  
            | GREATER => Node (L, (n, y), set R (i - n - 1) x)
          )

    fun rightmost Empty = raise Subscript
      | rightmost (Node (L, (_, y), Empty)) = (y, L)
      | rightmost (Node (L, x, R)) =
          let
            val (y, R') = rightmost R
          in
            (y, Node (L, x, R'))
          end
    
    fun pop Empty _ = raise Subscript
      | pop (Node (Empty, (0, x), R)) 0 = (x, R)
      | pop (Node (L, (n, x), R)) i = 
          (case Int.compare (i, n) of
              LESS => 
                let
                  val (y, L') = pop L i
                in
                  (y, Node (L', (n - 1, x), R))
                end
            | EQUAL => 
                let
                  val (y, L') = rightmost L
                in
                  (x, Node (L', (n - 1, y), R))
                end
            | GREATER => 
                let
                  val (y, R') = pop R (i - n - 1)
                in
                  (y, Node (L, (n, x), R'))
                end
          )
    
    fun length Empty = 0 
      | length (Node (L, (n, _), R)) = n + 1 + length R 
  end