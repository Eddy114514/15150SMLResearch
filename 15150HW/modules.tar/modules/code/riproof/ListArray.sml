structure ListArray :> ARRAY =
  struct
    type 'a t = 'a list

    exception Subscript

    val new_array = []

    fun nth [] i = raise Subscript
      | nth (x::_) 0 = x
      | nth (x::xs) i = nth xs (i - 1)
    
    fun insert L 0 x = x::L
      | insert (y::ys) i x = y :: (insert ys (i - 1) x)
      | insert [] _ _ = raise Subscript
    
    fun set (y::ys) 0 x = x::ys
      | set (y::ys) i x = y :: (set ys (i - 1) x)
      | set [] _ _ = raise Subscript

    fun pop [] i = raise Subscript
      | pop (x::xs) 0 = (x, xs)
      | pop (x::xs) i = 
          let
            val (y, ys) = pop xs (i - 1)
          in
            (y, x::ys)
          end
    
    val length = List.length
  end