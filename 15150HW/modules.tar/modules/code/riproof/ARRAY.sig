signature ARRAY =
  sig
    type 'a t
    exception Subscript

    val new_array : 'a t
    val nth : 'a t -> int -> 'a
    val insert : 'a t -> int -> 'a -> 'a t
    val set : 'a t -> int -> 'a -> 'a t
    val pop : 'a t -> int -> ('a * 'a t)
    val length : 'a t -> int 
  end