(* Implement your Book structure here! *)
