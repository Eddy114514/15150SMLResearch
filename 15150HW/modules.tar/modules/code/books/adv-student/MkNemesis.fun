(* Write a negation functor called MkNemesis here! *)
