(* Implement MkCompose, taking in StudentA and StudentB, here! *)
