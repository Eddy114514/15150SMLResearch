(* Write the Reset structure here! *)
