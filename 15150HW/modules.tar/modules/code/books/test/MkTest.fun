functor MkTest (Book : BOOK) :> TEST =
struct
  exception Error

  val test = fn () =>
    let
      val B0 = Book.bind []

      val () = (
        case Book.currentPage B0 of
          (true, NONE) => ()
        | _ => raise Error
      )

      val () = (
        case Book.unbind B0 of
          [] => ()
        | _ => raise Error
      )

      (* testing for unhandled Book.OutOfBounds exception *)
      val () = let val _ = Book.flip Book.FORWARD B0 in raise Error end handle Book.OutOfBounds => ()

      val B1 = Book.bind ["polly","honk"]

      (* Add more tests here *)
    in
      ()
    end
end
