(* Your functor MkStudent goes here. *)
