(* Instantiate MkStudent to create Honk *)
