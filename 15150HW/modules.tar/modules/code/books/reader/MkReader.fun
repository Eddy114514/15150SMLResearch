(* Your MkReader functor, taking in a Student structure, goes here. *)
