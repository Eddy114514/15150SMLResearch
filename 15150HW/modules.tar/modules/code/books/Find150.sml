structure Find150 :> sig val is150Book : Book.page list -> bool end =
struct

  (* is150Book : Book.page list -> bool
   * REQUIRES: true
   * ENSURES:
   *   is150Book b = true iff b contains at least three instance of
   *   the word "lambda" and no instances of the word "pointer"
   *)
  fun is150Book b = raise Fail "Unimplemented"
end
