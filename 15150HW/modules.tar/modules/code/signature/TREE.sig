signature TREE =
  sig
    (* Fill me in! *)
  end
