signature FOREST =
  sig
    type 'a forest
    (* Fill me in! *)
  end
