structure Utils :> UTILS =
struct
  (* collect: ('a * 'a -> order) -> 'a Seq.t -> 'a Seq.t Seq.t
   * REQUIRES:
   *    cmp is "well-behaved"
   *    cmp is total
   *    cmp has O(1) work/span
   * ENSURES: collect cmp S ==> C where
   *    Every element in S appears in some sequence of C
   *    If you sum the lengths of the sequences in C, you get the length of S
   *    Elements in each sequence in C are cmp-EQUAL
   *    Elements in earlier sequences in C are cmp-LESS than elements in
   *      later sequences in C
   *    No sequence in C is empty
   *    collect cmp S has O(|S|log|S|) work
   *    collect cmp S has O(log^2|S|) span
   *)

  fun collect cmp S =
    (* Don't forget to comment the work and span of each line of your implementation so
     * you don't lose points! This means you shouldn't write a one-line
     * implementation. Consider using a let expression or helper functions
     * to break your code into chunks that are easy to reason about and comment.
     *)
    raise Fail "Unimplemented"

  (* unique: ('a * 'a -> order) -> 'a Seq.t -> 'a Seq.t
   * REQUIRES:
   *    cmp is "well-behaved" (it is reflexive, anti-symmetric, and transitive)
   *    cmp is total and has O(1) work and span
   * ENSURES: unique cmp S ==> T where
   *    Each element of S has an EQUAL element in T
   *    The elements of T are in strictly increasing order (this prevents
   *      the existence of duplicates)
   *    unique cmp S has O(|S| log |S|) work and O(log^2 |S|) span
   *)

  fun unique cmp S =
    raise Fail "Unimplemented"

end
