functor MkTracker (Utils: UTILS) :> TRACKER =
struct

  (* you may assume this is a refsol for utils *)
  val unique = Utils.unique

  type mascot = int
  type chat = mascot Seq.t
  (* Don't forget to comment your tracker datatype! *)
  type tracker = unit

  (* empty: int -> tracker
   * REQUIRES:
   *    n >= 0
   * ENSURES:
   *    empty n reflects that there are no group chats created and a mascot
   *      index is from 0 to n-1. This representation should support all
   *      calls to addChat and query
   *)
  fun empty (n : int) : tracker =
    raise Fail "Unimplemented"

  (* addChat: tracker -> chat -> tracker
   * REQUIRES:
   *    Every member of the new chat has an index in 0 to n-1
   *    The chat has no duplicates
   *    T can be produced through calls to empty and addChat
   * ENSURES:
   *    addChat T C represents both C and the chats in T while maintaining the
   *      necessary invariants to give the right answer under future calls
   *      to addChat and query.
   *    O(|C| n log n) work and O(log^2 n) span.
   *)
  fun addChat (T : tracker) (C : chat) : tracker =
    (* Don't forget to comment the work and span of each line! *)
    raise Fail "Unimplemented"

  (* query: tracker -> mascot -> int -> mascot Seq.t
   * REQUIRES:
   *    The mascot has an index from 0 to n-1
   *    The resolution is non-negative
   *    T can be produced through calls to empty and addChat
   * ENSURES: query T m r ==> A
   *    A contains every mascot from 0 to n − 1 such that there exists mascots
   *      s0, s1, . . . , sr where s0 = m and for all 0 ≤ i < r, si and
   *      s(i+1) share a chat or si = s(i+1)
   *    O(r n^2 log n) work and O(r * log^2 n) span
   *)
  fun query (T : tracker) (m : mascot) (r : int) : mascot Seq.t =
    (* Don't forget to comment the work and span of each line! *)
    raise Fail "Unimplemented"

end
