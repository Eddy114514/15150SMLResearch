datatype tree = Empty | Node of tree * int * tree

(* isSymmetric : tree -> bool
 * REQUIRES: true
 * ENSURES: isSymmetric T ==>* true iff T is symmetric w.r.t the root
 *)
fun isSymmetric (_ : tree) : bool = raise Fail "Unimplemented"
