type interval = int * int

(* all_available : interval list list -> interval list
 * REQUIRES:
 *   - Each person's obligations are disjoint
 *   - All schedules are well-formatted
 *   - Assume time starts at 0 and ends at the largest number given in the input
 *   - Assume that people can instantly transport themselves to and from commitments
 * ENSURES:
 *   all_available LL = L where L is a single list of all non-degenerate intervals
 *   in any order for which everyone is available.
 *)


(*O(1)*)
fun pairCompare ((a,b),(c,d)) = 
  case Int.compare(a,c) of
   LESS => LESS
  |EQUAL => Int.compare(b,d)
  |GREATER => Int.compare(b,d)



fun findHelp ((a,b), (x,xs)) = if x < a then (b,(x,a)::xs) else (b,xs) (*O(1)*)


(*O(1)*)
fun mergeInter ((a,b):int*int, acc:(int*int) list) = 
    case acc of
        [] => [(a,b)]
      | (x,y)::xs => if b < x orelse a > y then 
                         (a,b)::acc
                     else 
                         (Int.min(a, x), Int.max(b, y))::xs




fun all_available ([] : interval list list) : interval list =  [] 
  | all_available L = 
  let
    val listSch = List.concat L 
    val sortSch = msort pairCompare listSch
    (*Above two are O(N) and O(NlogN) by PDF*)

    val mergeSch = foldr mergeInter [] sortSch 
    val gapSch = foldl findHelp (0,[]) mergeSch 
    (*Above 2 are O(N) becasue applying O(1) for at most N time*)
  in
    (fn (x,xs) => xs) gapSch (*O(1)*)
  end

(*Therefore, the big O is about 2*O(N) + O(NlogN)*)
(*Which is of course, O(NlogN)*)



    
val () = Test.list_eq (op= , MakeString.int_int )
( " all_available_empty "
, []
, all_available []
)
val () = Test.list_eq (op= , MakeString.int_int )
( " all_available_1 "
, [(3 ,4),(0 ,1)]
, all_available [[(1 ,2) ,(4 ,6) ,(8 ,12) ] ,[(1 ,3) ,(5 ,9) ]]
)
val () = Test.list_eq (op= , MakeString.int_int )
( " all_available_2 "
, [(3 ,5),(1 ,2) ]
, all_available [[(0 ,1) , (2 ,3) ] , [(5 ,7) ]]
)
val () = Test.list_eq (op= , MakeString.int_int )
( " all_available_3 "
, [(1 ,2) ]
, all_available [[(0 ,1) , (2 ,3) ]]
)







